package com.example.hack36;
import java.util.ArrayList;
public class Hospitals {
    String name;
    ArrayList<DocTypes> dt;
    public Hospitals(){}
    public Hospitals(String name,ArrayList<DocTypes> dt){
        this.name=name;
        this.dt=dt;
    }
}
