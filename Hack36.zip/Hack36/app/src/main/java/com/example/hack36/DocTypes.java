package com.example.hack36;
import java.util.ArrayList;
public class DocTypes {
    String name;
    ArrayList<Doctors> doc;
    public DocTypes(){}
    public DocTypes(String name,ArrayList<Doctors> doc){
        this.name=name;
        this.doc=doc;
    }
}
