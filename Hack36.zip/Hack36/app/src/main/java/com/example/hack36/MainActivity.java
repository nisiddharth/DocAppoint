package com.example.hack36;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
      Button add;
      EditText e1,e2,e3,e4,e5,e6,e7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseApp.initializeApp(this);
        final DatabaseReference myRef=FirebaseDatabase.getInstance().getReference("cities");
        add=(Button)findViewById(R.id.button);
        add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                e1=(EditText)findViewById(R.id.city);
                e2=(EditText)findViewById(R.id.Hospital);
                e3=(EditText)findViewById(R.id.docname);
                e4=(EditText)findViewById(R.id.type);
                e5=(EditText)findViewById(R.id.from);
                e6=(EditText)findViewById(R.id.to);
                e7=(EditText)findViewById(R.id.fees);
                Doctors doc=new Doctors(e3.getText().toString(),e5.getText().toString()+"-"+e6.getText().toString(),e7.getText().toString());
                DocTypes dt=new DocTypes(e4.getText().toString(),new ArrayList<Doctors>());
                dt.doc.add(doc);
                Hospitals hp=new Hospitals(e2.getText().toString(),new ArrayList<DocTypes>());
                hp.dt.add(dt);
                Cities ct=new Cities(e1.getText().toString(),new ArrayList<Hospitals>());
                ct.hospitals.add(hp);
                myRef.setValue(ct);
            }
        });
    }
}
