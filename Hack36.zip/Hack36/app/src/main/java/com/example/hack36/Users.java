package com.example.hack36;

public class Users {
    String name,mobno,dob;
    public Users(){}
    public Users(String name,String mobno,String dob){
        this.name=name;
        this.mobno=mobno;
        this.dob=dob;
    }
}
