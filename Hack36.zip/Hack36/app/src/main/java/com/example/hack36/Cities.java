package com.example.hack36;
import java.util.ArrayList;
public class Cities {
    ArrayList<Hospitals> hospitals;
    String name;
    public Cities(){}
    public Cities(String name,ArrayList<Hospitals> hospitals){
        this.hospitals=hospitals;
        this.name=name;
    }
}
