package com.example.hack36;

public class Doctors {
    public String name,time,fees;
    public Doctors(){}
    public Doctors(String name,String time,String fees){
        this.name=name;
        this.time=time;
        this.fees=fees;

    }
}
