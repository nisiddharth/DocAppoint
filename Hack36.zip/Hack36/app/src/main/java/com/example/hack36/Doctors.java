package com.example.hack36;

public class Doctors {
    public String name,time,fees,city,hospital,type;
    public Doctors(){}
    public Doctors(String name,String time,String fees,String city,String hospital,String type){
        this.name=name;
        this.time=time;
        this.fees=fees;
        this.city=city;
        this.hospital=hospital;
        this.type=type;

    }
}
