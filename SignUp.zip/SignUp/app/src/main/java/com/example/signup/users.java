package com.example.signup;

public class users {
    String name,dob,mob;
    public users()
    {}
    public users(String name,String dob,String mob)
    {
        this.name=name;
        this.dob=dob;
        this.mob=mob;
    }
}
